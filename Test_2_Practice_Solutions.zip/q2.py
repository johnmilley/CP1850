def display_statistics(grades):
    print(f"Min: {min(grades)}")
    print(f"Max: {max(grades)}")
    print(f"Average: {sum(grades) / len(grades)}")

def main():
    grades = []
    counter = 0

    while counter < 5:
        grade = float(input("Enter a grade: "))
        if grade >= 1 and grade <= 100:
            grades.append(grade)
            counter += 1
        else: 
            print("\nInvalid grade. Must be between 1-100.\n")

    display_statistics(grades)

if __name__ == "__main__":
    main()
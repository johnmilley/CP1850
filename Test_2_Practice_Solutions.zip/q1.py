
# one solution
def password_to_asterisks(s):
    asterisks = ""
    for c in s:
        asterisks += "*"
    return asterisks

# another solution
def password_to_asterisks(s):
    converted_to_asterisks = "*" * len(s)
    return converted_to_asterisks

# more concise version of the above function
# def password_to_asterisks(s):
#     return "*" * len(s)

print(password_to_asterisks("hello"))
print(password_to_asterisks("passw0rd"))
print(password_to_asterisks("hello"))



# import random
from random import randint

def roll(n: int):
    roll_list = []
    for i in range(n):
        roll = randint(1, 6)
        roll_list.append(roll)
    return roll_list

def display_roll_frequency(rolls: list) -> None:
    
    # the long way
    # ones = 0
    # for roll in rolls:
    #     if roll == 1:
    #         ones += 1

    # using built-in functions
    print(f"1: {rolls.count(1)}")
    print(f"2: {rolls.count(2)}")
    print(f"3: {rolls.count(3)}")
    print(f"4: {rolls.count(4)}")
    print(f"5: {rolls.count(5)}")
    print(f"6: {rolls.count(6)}")


display_roll_frequency(roll(100))
display_roll_frequency(roll(1000))
display_roll_frequency(roll(10_000))
display_roll_frequency(roll(100_000))


import random

def attack(base: int, modifiers: list):
    return base * modifiers[random.randint(0, 9)]

attack_modifiers = [1, 1, 1, 1, 1.5, 2, 4, 0.8, 0.5, 0]  # 10, index 0-9
base_damage = 10

print(attack(base_damage, attack_modifiers))
print(attack(base_damage, attack_modifiers))
print(attack(base_damage, attack_modifiers))
print(attack(base_damage, attack_modifiers))
print(attack(base_damage, attack_modifiers))
print(attack(base_damage, attack_modifiers))
